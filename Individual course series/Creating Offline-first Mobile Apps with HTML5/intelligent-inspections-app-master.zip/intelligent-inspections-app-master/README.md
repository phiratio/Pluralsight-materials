# Intelligent Inspections Mobile Inspection Form

These are the files used in the Pluralsight course: Creating Offline-first Mobile Apps with HTML5
https://app.pluralsight.com/library/courses/html5-creating-offline-first-mobile-apps/table-of-contents

Please let me know if you find any issues with these files or find any errors.