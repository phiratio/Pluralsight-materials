<div id="header">
    <div id="nav"><a href="index.php">Home</a> | <a href="customers.php">Customers</a> | <a href="properties.php">Properties</a> | <a href="inspections.php">Inspections</a></div>
    <img src="images/inspector-300px.png" id="logo" class="left" width="212" height="300" alt="intelligent inspector">
    <h1>Intelligent Inspections, Inc.</h1>
</div>