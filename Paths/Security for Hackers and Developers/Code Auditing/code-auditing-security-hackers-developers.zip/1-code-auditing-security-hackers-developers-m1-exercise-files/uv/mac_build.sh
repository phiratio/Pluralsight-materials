#gcc -fprofile-arcs -ftest-coverage -g uv.c 

clang -w -fprofile-arcs -ftest-coverage -g uv.c -o uv
