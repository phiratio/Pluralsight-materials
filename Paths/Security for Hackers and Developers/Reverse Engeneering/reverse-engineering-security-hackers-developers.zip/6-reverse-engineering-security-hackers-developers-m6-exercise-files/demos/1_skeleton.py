key = ? 
encoded = ?
decoded = ""
c = 0

index = 0
while 1:
	?

print decoded