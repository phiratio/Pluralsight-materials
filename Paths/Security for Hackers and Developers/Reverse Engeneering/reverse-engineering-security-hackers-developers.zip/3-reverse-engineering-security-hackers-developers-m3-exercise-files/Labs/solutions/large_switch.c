#include<stdio.h>
int main(int argc, char * argv[]) {
	int i=atoi(argv[1]);

	switch(i) {
		case 10:
			printf("you got 10!\n");
			break;
		case 20:
			printf("you got 20!\n");
			break;
		case 30:
			printf("you got 30!\n");
			break;
		case 40:
			printf("you got 40!\n");
			break;
		case 50:
			printf("you got 50!\n");
			break;
		case 60:
			printf("you got 60!\n");
			break;
		case 70:
			printf("you got 70!\n");
			break;
		case 80:
			printf("you got 80!\n");
			break;
		case 90:
			printf("you got 90!\n");
			break;
		case 100:
			printf("you got 100!\n");
			break;
		default:
			printf("you got nothing...\n");
			break;
	}
}
			

