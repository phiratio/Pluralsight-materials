
struct person {
	char name[30];
	int age;
	float hatsize;
	void * nextperson;
};
