#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

#define BACKLOG 1     // how many pending connections queue will hold

int connect_handler(int clientsocket)
{
	int cs;
	char buf[100];
	char bufin[20];
	char bufcmp[5] = {"31337"};
	
	memset(buf, 0x00, sizeof(buf));
	strcpy(buf, "Welcome to the server. Enter the password\r\n");
	
	if(( cs = send(clientsocket, buf, strlen(buf), 0)) <1)
	{
		perror("couldnt send");
		exit(1);
	}
	
	memset(bufin, 0x00,sizeof(bufin));
	
	read(clientsocket, bufin, 200);

	printf("Received: %s", bufin);
	fflush(stdout);
}

int main(int argc, char * argv[])
{
	if (argc!= 3)
	{ 
	  fprintf(stderr, "Please enter a IP and port\n"); 
	  exit(1); 
	}
	
	struct hostent * serverip;
	struct sockaddr_in server_addr;    // my address information
    struct sockaddr_in client_addr; // connector's address information
    int sockfd, new_fd;  // listen on sock_fd, new connection on new_fd
    unsigned int sin_size = sizeof client_addr;    
    
    serverip = gethostbyname(argv[1]);
    int MYPORT = atoi(argv[2]);  

	
    if ((sockfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) 
    {
        perror("socket");
        exit(1);
    }
	
    server_addr.sin_family = AF_INET;         // host byte order
    server_addr.sin_port = htons(MYPORT);     // short, network byte order
    server_addr.sin_addr = *((struct in_addr *)serverip->h_addr);	// address	
    memset(server_addr.sin_zero, '\0', sizeof server_addr.sin_zero);

    if(bind(sockfd, (struct sockaddr *)&server_addr, sizeof server_addr) == -1)
    {
    	perror("Failed to bind");
        exit(1);
    }
  
 	if(listen(sockfd, BACKLOG) == -1)
 	{
 		perror("Failed in listen");
 		exit(1);
 	}

 
	while(1)
	{
    		if((new_fd = accept(sockfd, (struct sockaddr *)&client_addr,
						 &sin_size)) == -1)
    		{
    			perror("Failed in accept");
    		}

		if( connect_handler(new_fd) == -1)
			printf("connection_handler didn't go well...\r\n");
    		close(new_fd);
	}
	
	
   	close(sockfd);  
    
    return (0);  
}
