./easyd 0.0.0.0 31338 & sleep 1 ; gdb ./easyd `ps ax|grep -v grep| grep eas
yd| cut -c-6`
