#!/usr/bin/python

import socket, sys

if len(sys.argv) != 3:
	print "supply IP PORT"
	sys.exit(-1)
  


