#!/bin/bash
while [ 1 ]; do
	./threaded-server.exe 0.0.0.0
done
