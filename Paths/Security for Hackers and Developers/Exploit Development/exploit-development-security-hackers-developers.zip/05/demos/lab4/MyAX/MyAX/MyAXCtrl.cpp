// MyAXCtrl.cpp : Implementation of the CMyAXCtrl ActiveX Control class.

#include "stdafx.h"
#include "MyAX.h"
#include "MyAXCtrl.h"
#include "MyAXPropPage.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

void trace(const char *msg) {
	FILE *out;
	fopen_s(&out, "C:\\Users\\AppSec\\AppData\\Local\\Temp\\myax_jared.log", "a");
	if( out != NULL)
	{
		fputs(msg, out);
		fclose(out);
	}
}

IMPLEMENT_DYNCREATE(CMyAXCtrl, COleControl)



// Message map

BEGIN_MESSAGE_MAP(CMyAXCtrl, COleControl)
	ON_OLEVERB(AFX_IDS_VERB_PROPERTIES, OnProperties)
END_MESSAGE_MAP()



// Dispatch map

BEGIN_DISPATCH_MAP(CMyAXCtrl, COleControl)
	DISP_FUNCTION_ID(CMyAXCtrl, "AboutBox", DISPID_ABOUTBOX, AboutBox, VT_EMPTY, VTS_NONE)
	DISP_FUNCTION_ID(CMyAXCtrl, "VulnFunc", 1, VulnFunc, VT_NULL, VTS_WBSTR)
END_DISPATCH_MAP()



// Event map

BEGIN_EVENT_MAP(CMyAXCtrl, COleControl)
END_EVENT_MAP()



// Property pages

// TODO: Add more property pages as needed.  Remember to increase the count!
BEGIN_PROPPAGEIDS(CMyAXCtrl, 1)
	PROPPAGEID(CMyAXPropPage::guid)
END_PROPPAGEIDS(CMyAXCtrl)



// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CMyAXCtrl, "MYAX.MyAXCtrl.1",
	0x3d5a15f5, 0xdab1, 0x4132, 0x97, 0xc0, 0x9f, 0xeb, 0xcd, 0xb4, 0x73, 0xd6)



// Type library ID and version

IMPLEMENT_OLETYPELIB(CMyAXCtrl, _tlid, _wVerMajor, _wVerMinor)



// Interface IDs

const IID BASED_CODE IID_DMyAX =
		{ 0xA4AE6BC7, 0xB7B2, 0x46BE, { 0xB5, 0x71, 0xD0, 0xAF, 0x8D, 0x99, 0xBA, 0xA } };
const IID BASED_CODE IID_DMyAXEvents =
		{ 0xA401C027, 0xE54, 0x46F8, { 0x8C, 0xC, 0x96, 0x8, 0x1, 0xC8, 0x16, 0xAC } };



// Control type information

static const DWORD BASED_CODE _dwMyAXOleMisc =
	OLEMISC_ACTIVATEWHENVISIBLE |
	OLEMISC_SETCLIENTSITEFIRST |
	OLEMISC_INSIDEOUT |
	OLEMISC_CANTLINKINSIDE |
	OLEMISC_RECOMPOSEONRESIZE;

IMPLEMENT_OLECTLTYPE(CMyAXCtrl, IDS_MYAX, _dwMyAXOleMisc)



// CMyAXCtrl::CMyAXCtrlFactory::UpdateRegistry -
// Adds or removes system registry entries for CMyAXCtrl

BOOL CMyAXCtrl::CMyAXCtrlFactory::UpdateRegistry(BOOL bRegister)
{
	// TODO: Verify that your control follows apartment-model threading rules.
	// Refer to MFC TechNote 64 for more information.
	// If your control does not conform to the apartment-model rules, then
	// you must modify the code below, changing the 6th parameter from
	// afxRegApartmentThreading to 0.

	if (bRegister)
		return AfxOleRegisterControlClass(
			AfxGetInstanceHandle(),
			m_clsid,
			m_lpszProgID,
			IDS_MYAX,
			IDB_MYAX,
			afxRegApartmentThreading,
			_dwMyAXOleMisc,
			_tlid,
			_wVerMajor,
			_wVerMinor);
	else
		return AfxOleUnregisterClass(m_clsid, m_lpszProgID);
}



// CMyAXCtrl::CMyAXCtrl - Constructor

CMyAXCtrl::CMyAXCtrl()
{
	InitializeIIDs(&IID_DMyAX, &IID_DMyAXEvents);
	// TODO: Initialize your control's instance data here.
}



// CMyAXCtrl::~CMyAXCtrl - Destructor

CMyAXCtrl::~CMyAXCtrl()
{
	// TODO: Cleanup your control's instance data here.
}



// CMyAXCtrl::OnDraw - Drawing function

void CMyAXCtrl::OnDraw(
			CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid)
{
	trace("CMyAXCtrl::OnDraw\n");
	if (!pdc)
		return;

	// TODO: Replace the following code with your own drawing code.
	pdc->FillRect(rcBounds, CBrush::FromHandle((HBRUSH)GetStockObject(WHITE_BRUSH)));
	pdc->Ellipse(rcBounds);
}



// CMyAXCtrl::DoPropExchange - Persistence support

void CMyAXCtrl::DoPropExchange(CPropExchange* pPX)
{
	ExchangeVersion(pPX, MAKELONG(_wVerMinor, _wVerMajor));
	COleControl::DoPropExchange(pPX);

	// TODO: Call PX_ functions for each persistent custom property.
}



// CMyAXCtrl::OnResetState - Reset control to default state

void CMyAXCtrl::OnResetState()
{
	COleControl::OnResetState();  // Resets defaults found in DoPropExchange

	// TODO: Reset any other control state here.
}



// CMyAXCtrl::AboutBox - Display an "About" box to the user

void CMyAXCtrl::AboutBox()
{
	trace("CMyAXCtrl::AboutBox\n");
	CDialog dlgAbout(IDD_ABOUTBOX_MYAX);
	dlgAbout.DoModal();
}

//jdd:
void CMyAXCtrl::VulnFunc(BSTR wstr)
{
	trace("CMyAXCtrl::VulnFunc\n");
	WCHAR buf[200];
	//wcscpy_s(buf, 800000, wstr);
	memmove(buf, wstr, 100000);
}

///////////////////////////////////////////////////////////////////////////////
// IObjectSafety
//
// Note, this interface needs to be implemented that we are able to run
//       JScript functions through IDispatch.
//
HRESULT CMyAXCtrl::GetInterfaceSafetyOptions(REFIID riid, DWORD *pdwSupportedOptions, DWORD *pdwEnabledOptions)
{
	//*pdwSupportedOptions = *pdwEnabledOptions = INTERFACESAFE_FOR_UNTRUSTED_CALLER|INTERFACESAFE_FOR_UNTRUSTED_DATA;
	trace("CMyAXCtrl::GetetInterfaceSafetyOptions\n");
	*pdwSupportedOptions = *pdwEnabledOptions = 0x00000001|0x00000002;
	return S_OK;
}

HRESULT CMyAXCtrl::SetInterfaceSafetyOptions(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions)
{
	trace("CMyAXCtrl::SetInterfaceSafetyOptions\n");
	//return S_OK;
	__asm {
		add esp, 0x18
			ret
	}
	__asm {
		add     esp, 0x5b4
			ret
	}
	__asm{
		add     esp, 0x584
		ret
	}
	__asm {
		add     esp, 0x40c
			ret
	}
	__asm {
		mov edx, 0x40
			ret
	}
	__asm {
		pushad
			ret
	}
	VirtualProtect((void *)0x10001000, 0x100, 0x40, NULL);
	__asm
	{
		ret
	}
	__asm {
		int 3
			ret
	}
	__asm {
		mov[esp+0x10], esp
			ret
	}
	__asm{
			mov ebx, esp
			add ebx, 0x1c
			mov [esp+0x8], ebx
				ret
	}

}

///////////////////////////////////////////////////////////////////////////////
// IUnknown
ULONG CMyAXCtrl::AddRef(void) {
	
	trace("CMyAXCtrl::AddRef\n");
	return ++ref;
}

ULONG CMyAXCtrl::Release(void) {
	trace("CMyAXCtrl::Release\n");
	return ref > 0 ? --ref : 0;
}

HRESULT CMyAXCtrl::QueryInterface(REFIID riid, void __RPC_FAR *__RPC_FAR *ppvObject)
{
	*ppvObject = NULL;
	if(riid == IID_IUnknown) {
		trace("CMyAXCtrl::QueryInterface - IUnknown\n");
		*ppvObject = (LPUNKNOWN)this;
		((LPUNKNOWN)*ppvObject)->AddRef();
		return S_OK;
	}
	else if(riid == IID_IDispatch) {
		trace("CMyAXCtrl::QueryInterface - IDispatch\n");
		*ppvObject = (LPDISPATCH)this;
		((LPUNKNOWN)*ppvObject)->AddRef();
		return S_OK;
	}
	else if(riid == IID_IClassFactory) {
		trace("CMyAXCtrl::QueryInterface - IClassFactory\n");
		*ppvObject = (LPCLASSFACTORY)this;
		((LPUNKNOWN)*ppvObject)->AddRef();
		return S_OK;
	}
	else if(riid == IID_IObjectWithSite) {
		trace("CMyAXCtrl::QueryInterface - IObjectWithSite\n");
		*ppvObject = (LPOBJECTWITHSITE)this;
		((LPUNKNOWN)*ppvObject)->AddRef();
		return S_OK;
	}
	else if(riid == IID_IObjectSafety) {
		trace("CMyAXCtrl::QueryInterface - IObjectSafety\n");
		*ppvObject = (LPOBJECTSAFETY)this;
		((LPUNKNOWN)*ppvObject)->AddRef();
		return S_OK;
	}

	trace("CMyAXCtrl::QueryInterface - unknown interface query\n");
	return E_NOINTERFACE;
}


// CMyAXCtrl message handlers
