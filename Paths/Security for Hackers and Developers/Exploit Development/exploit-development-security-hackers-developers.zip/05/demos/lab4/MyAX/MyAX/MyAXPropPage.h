#pragma once

// MyAXPropPage.h : Declaration of the CMyAXPropPage property page class.


// CMyAXPropPage : See MyAXPropPage.cpp for implementation.

class CMyAXPropPage : public COlePropertyPage
{
	DECLARE_DYNCREATE(CMyAXPropPage)
	DECLARE_OLECREATE_EX(CMyAXPropPage)

// Constructor
public:
	CMyAXPropPage();

// Dialog Data
	enum { IDD = IDD_PROPPAGE_MYAX };

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Message maps
protected:
	DECLARE_MESSAGE_MAP()
};

