#pragma once

// MyAXCtrl.h : Declaration of the CMyAXCtrl ActiveX Control class.
//#define COM_NO_WINDOWS_H 0
//#include "helpers.h"
#include <comcat.h>
#include <objsafe.h> //was causing issues: jdd, but i added after adding IObjectSafety stuff
// CMyAXCtrl : See MyAXCtrl.cpp for implementation.

class CMyAXCtrl : public COleControl, public IObjectSafety
{
	DECLARE_DYNCREATE(CMyAXCtrl)
	
private:
	ULONG     ref;

// Constructor
public:
	CMyAXCtrl();

// Overrides
public:
	virtual void OnDraw(CDC* pdc, const CRect& rcBounds, const CRect& rcInvalid);
	virtual void DoPropExchange(CPropExchange* pPX);
	virtual void OnResetState();

// Implementation
protected:
	~CMyAXCtrl();

	DECLARE_OLECREATE_EX(CMyAXCtrl)    // Class factory and guid
	DECLARE_OLETYPELIB(CMyAXCtrl)      // GetTypeInfo
	DECLARE_PROPPAGEIDS(CMyAXCtrl)     // Property page IDs
	DECLARE_OLECTLTYPE(CMyAXCtrl)		// Type name and misc status

// Message maps
	DECLARE_MESSAGE_MAP()

// Dispatch maps
	DECLARE_DISPATCH_MAP()

	afx_msg void AboutBox();

//jdd:
	afx_msg void VulnFunc(BSTR);

// Event maps
	DECLARE_EVENT_MAP()

// Dispatch and event IDs
public:
	enum {
	};

	//////////////////////////////////////////////////////////////////
	// IObjectSafety
	HRESULT STDMETHODCALLTYPE GetInterfaceSafetyOptions(REFIID riid, DWORD *pdwSupportedOptions, DWORD *pdwEnabledOptions);

	HRESULT STDMETHODCALLTYPE SetInterfaceSafetyOptions(REFIID riid, DWORD dwOptionSetMask, DWORD dwEnabledOptions);

	//////////////////////////////////////////////////////////////////
	// IUnknown
	HRESULT STDMETHODCALLTYPE QueryInterface(REFIID riid, void __RPC_FAR *__RPC_FAR *ppvObject);

	ULONG STDMETHODCALLTYPE AddRef(void);

	ULONG STDMETHODCALLTYPE Release(void);

};

