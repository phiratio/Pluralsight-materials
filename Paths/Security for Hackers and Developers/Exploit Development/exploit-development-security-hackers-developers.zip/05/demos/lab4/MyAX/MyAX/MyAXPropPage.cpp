// MyAXPropPage.cpp : Implementation of the CMyAXPropPage property page class.

#include "stdafx.h"
#include "MyAX.h"
#include "MyAXPropPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


IMPLEMENT_DYNCREATE(CMyAXPropPage, COlePropertyPage)



// Message map

BEGIN_MESSAGE_MAP(CMyAXPropPage, COlePropertyPage)
END_MESSAGE_MAP()



// Initialize class factory and guid

IMPLEMENT_OLECREATE_EX(CMyAXPropPage, "MYAX.MyAXPropPage.1",
	0xcab77341, 0x363c, 0x4f93, 0xaf, 0x36, 0x2b, 0x55, 0xa4, 0x19, 0xa2, 0xec)



// CMyAXPropPage::CMyAXPropPageFactory::UpdateRegistry -
// Adds or removes system registry entries for CMyAXPropPage

BOOL CMyAXPropPage::CMyAXPropPageFactory::UpdateRegistry(BOOL bRegister)
{
	if (bRegister)
		return AfxOleRegisterPropertyPageClass(AfxGetInstanceHandle(),
			m_clsid, IDS_MYAX_PPG);
	else
		return AfxOleUnregisterClass(m_clsid, NULL);
}



// CMyAXPropPage::CMyAXPropPage - Constructor

CMyAXPropPage::CMyAXPropPage() :
	COlePropertyPage(IDD, IDS_MYAX_PPG_CAPTION)
{
}



// CMyAXPropPage::DoDataExchange - Moves data between page and properties

void CMyAXPropPage::DoDataExchange(CDataExchange* pDX)
{
	DDP_PostProcessing(pDX);
}



// CMyAXPropPage message handlers
