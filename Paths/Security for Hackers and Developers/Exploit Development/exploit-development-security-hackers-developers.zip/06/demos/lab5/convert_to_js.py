import binascii, os, sys

f = open(sys.argv[1], 'rb')
bytes = f.read()
f.close()


b1 = ""
b2 = ""
sc = ""
second = 0
for b in bytes:
	if second == 0:
		sc += "%u"
		b1 = binascii.hexlify(b)
		second += 1
	else:
		b2 = binascii.hexlify(b)
		sc += b2
		sc += b1
		second = 0


f = open("output.txt", "w")
f.write(sc)
f.close()
	
