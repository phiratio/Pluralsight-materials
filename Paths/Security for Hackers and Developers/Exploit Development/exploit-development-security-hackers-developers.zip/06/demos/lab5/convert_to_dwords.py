import binascii, os, sys

f = open(sys.argv[1], 'rb')
bytes = f.read()
f.close()


sc = ""
for i in bytes:
	sc += "0x"
	sc += binascii.hexlify(i)
	sc += ", "

f = open("dword_output.txt", "w")
f.write(sc)
f.close()
	
