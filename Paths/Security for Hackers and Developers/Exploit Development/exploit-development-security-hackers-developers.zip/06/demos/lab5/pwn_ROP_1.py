import os
import subprocess

input = "A" * 100

subprocess.call(["rop_stdin.exe", input])