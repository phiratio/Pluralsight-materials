#include <stdlib.h>
#include <stdio.h>

vuln()
{
  char buf[64];
  fread(buf, 1, 200, stdin);
}

mul(int a, int b)
{
  int c = a * b;
  printf("%d * %d = %d\n", a, b, c);
}

int main(int argc, char *argv[])
{
  mul(10,10);
  if (argv[1])
    vuln();
}