import binascii, os, sys

f = open(sys.argv[1], 'rb')
bytes = f.read()
f.close()


sc = ""
for b in bytes:
	sc += binascii.hexlify(b)
	sc += " "

f = open("output.txt", "w")
f.write(sc)
f.close()
	
