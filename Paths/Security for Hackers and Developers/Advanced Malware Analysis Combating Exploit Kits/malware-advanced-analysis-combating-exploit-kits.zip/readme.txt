Demos for this course can be found at the link below.

http://vdalabs.com/AdvMal/labs/