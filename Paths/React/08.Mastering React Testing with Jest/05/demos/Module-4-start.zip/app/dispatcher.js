let Dispatcher = require("flux").Dispatcher;
let instance = new Dispatcher();

module.exports = instance;
