module.exports = ()=>{
	return {
		id:"003",
		name:"Instant Noodles",
		description:"Tasty!",
		priceUSD:2.50
	}
}
