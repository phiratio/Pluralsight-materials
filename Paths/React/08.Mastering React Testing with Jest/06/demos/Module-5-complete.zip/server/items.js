module.exports = [{
    id:"401",
    name:"Box",
    description:"It's just an ordinary box, or is it?",
    priceUSD:34.95
},{
    id:"402",
    name:"Camera",
    description:"This small, lightweight camera can hold over 1000 high definition images.",
    priceUSD:155.95
},{
    id:"403",
    name:"Magazine",
    description:"One can't help but be distracted by this magazine.",
    priceUSD:9
}];
