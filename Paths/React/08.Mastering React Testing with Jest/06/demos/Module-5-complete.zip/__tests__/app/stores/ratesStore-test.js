describe("The Rates Store",()=>{
	
});