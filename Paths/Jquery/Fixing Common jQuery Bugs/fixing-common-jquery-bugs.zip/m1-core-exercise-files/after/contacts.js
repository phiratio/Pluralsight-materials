﻿[
    { "name": "John Smith" },
    { "name": "Jane Smith" },
    { "name": "Baby Smith" }
]