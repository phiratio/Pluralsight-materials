After opening the begin or end project in Visual Studio please
build the project so that Nuget can restore any missing packages.

The packages were left out of the projects in order to minimize 
the download size.

