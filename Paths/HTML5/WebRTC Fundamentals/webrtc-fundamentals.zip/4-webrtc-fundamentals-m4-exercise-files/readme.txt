For the best results, exercise files should be hosted on a (local or remote) web server and loaded in Chrome. 

Please keep in mind that WebRTC is in active development, so the APIs will change, as will browser compatibility. For updates and notes about the code examples and the WebRTC API, please check the course discussion page and http://LearnFromLisa.com. 

Surf the wave of change, and keep evolving. 


// Lisa Larson-Kelley