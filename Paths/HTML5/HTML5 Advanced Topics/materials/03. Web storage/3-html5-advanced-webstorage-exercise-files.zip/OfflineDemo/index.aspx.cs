﻿using System;

namespace OfflineDemo
{
    public partial class index : NoCachePage { }
}