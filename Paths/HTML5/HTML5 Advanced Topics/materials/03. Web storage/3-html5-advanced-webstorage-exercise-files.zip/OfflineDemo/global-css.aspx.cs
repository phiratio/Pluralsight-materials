﻿
namespace OfflineDemo
{
    public partial class global_css : NoCachePage { }
}