﻿using System;
using System.Web;

namespace OfflineDemo
{
    public partial class manifest : NoCachePage
    {

    }
}