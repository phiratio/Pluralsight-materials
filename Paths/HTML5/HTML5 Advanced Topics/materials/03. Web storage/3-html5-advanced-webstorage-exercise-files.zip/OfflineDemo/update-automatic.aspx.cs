﻿
namespace OfflineDemo
{
    public partial class update_automatic : NoCachePage
    {

    }
}