﻿
namespace OfflineDemo
{
    public partial class journal : NoCachePage { }
}