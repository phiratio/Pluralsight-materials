﻿
namespace OfflineDemo
{
    public partial class debug_manifest : NoCachePage { }
}