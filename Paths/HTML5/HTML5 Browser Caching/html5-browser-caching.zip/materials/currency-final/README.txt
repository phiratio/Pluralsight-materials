App Cache Demo App
==================

To run:

    rake server

Dependencies will be installed for you and a server will be started.

Visit:

    http://localhost:5000

