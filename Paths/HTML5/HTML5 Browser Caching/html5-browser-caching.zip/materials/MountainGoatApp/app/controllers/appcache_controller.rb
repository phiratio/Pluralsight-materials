class AppcacheController < ApplicationController
  
  layout false
  
end