class MountainGoatsController < ApplicationController
  
end