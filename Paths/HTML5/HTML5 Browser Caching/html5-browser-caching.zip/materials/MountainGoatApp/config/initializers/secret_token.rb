# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
MountainGoatApp::Application.config.secret_token = 'c5bf8bbc9f0ec8646771af814e2853776ca91d2b7f2a1384140079056f769ca511613f3fd299b23fec79a22188c39580961758534cb916f9aa1e9b4b56b34c6b'
