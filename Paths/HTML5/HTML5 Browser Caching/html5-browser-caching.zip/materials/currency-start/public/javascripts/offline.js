/* Make the application work offline */
$(function () {

});