Text Editor (Notepad will work)
Browser (FireFox is used in demo)

